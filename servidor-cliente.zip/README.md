# Taller-Prog_1-2021-1C-Magios

Equipo Magios

## Integrantes:
- Yussef Omar Mejia Cordoba
- Sabao Tomas
- Marco
- Vazquez Lareu Román
- Torres Dalmas, Nicolas
